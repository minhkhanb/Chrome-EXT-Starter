document.addEventListener('DOMContentLoaded', function () {
    console.log('abc');
    var checkPageButton = document.getElementById('checkPage');
    checkPageButton.addEventListener('click', function () {
        chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
            var p = document.createElement("p");
            p.innerHTML = "Hello chu Zit";
            document.body.appendChild(p);
        });
    }, false);
}, false);