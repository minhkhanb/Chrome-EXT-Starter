console.log('Hello world');
var h1 = document.createElement("h1");
h1.innerHTML = "năm nay 30/4 có plan gì ko chú Việt - Tuấn ?";
h1.style.fontSize = '72px';
document.body.textContent = '';
document.body.appendChild(h1);